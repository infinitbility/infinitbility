<!-- Main Content -->
<div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="post-preview card card-body">
        <a href="<?php echo e(url('post/'.$post->url)); ?>">
          <img src="<?php echo e($post->image); ?>" width="100%" />
          <h2 class="post-title">
            <?php echo e($post->title); ?>

          </h2>
          <h3 class="post-subtitle">
            <?php echo e($post->description); ?>

          </h3>
        </a>
        <p class="post-meta">Posted by
          <a href="#"><?php echo e($post->first_name.' '.$post->last_name); ?></a>
          on <?php echo e(date('M d, Y', strtotime($post->created_at))); ?></p>
      </div>
      <hr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Pager -->
        <div class="clearfix">
        <?php echo e($posts->links()); ?>

        </div>
      </div>
      <div class="col-lg-4 col-md-2 mx-auto">
      <?php $__currentLoopData = $sponsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="post-preview card card-body">
        <a href="<?php echo e($sponser->url); ?>">
          <img src="<?php echo e($sponser->image); ?>" width="100%" />
          <h2 class="post-title">
          <?php echo e($sponser->heading); ?>

          </h2>
          <h3 class="post-subtitle">
          <?php echo e($sponser->sub_heading); ?>

          </h3>
        </a>
        <p class="post-meta"><?php echo e($sponser->description); ?></p>
      </div>
      <hr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
  <?php /**PATH C:\xampp\htdocs\infinitbility\resources\views/website/pages/index.blade.php ENDPATH**/ ?>