<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Infinitbility Admin</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" type="image/png" href="<?php echo e(asset('images/icons/favicon.ico')); ?>"/>

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

         <!-- Scripts -->
        <!-- <script src="<?php echo e(asset('js/app.js')); ?>" defer></script> -->
        <!-- Fonts -->
        <!-- <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet"> -->

        <!-- Styles -->
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/util.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">
        <!--===============================================================================================-->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
        <!-- Icons -->
        <link rel="stylesheet" href="<?php echo e(asset('css/nucleo.css')); ?>" type="text/css">
        <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>" type="text/css">
        <!-- Argon CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('css/argon.css')); ?>" type="text/css">
        <script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>

    </head>
<body>
    <?php echo $__env->yieldContent('content', View::make($viewName, compact($veriables))); ?>
</body>
    <!--===============================================================================================-->
	    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
    <!--===============================================================================================-->
        <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <!--===============================================================================================-->
        <script src="<?php echo e(asset('js/main.js')); ?>"></script>
        <script src="<?php echo e(asset('js/argon.js')); ?>"></script>
        <script src="<?php echo e(asset('js/js.cookie.js')); ?>"></script>
</html><?php /**PATH C:\xampp\htdocs\infinitbility\resources\views/admin/layout/app.blade.php ENDPATH**/ ?>