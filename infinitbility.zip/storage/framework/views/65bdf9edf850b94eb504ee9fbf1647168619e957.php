<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
<!-- weball.min.css -->
  <title><?php echo $metaTags['title']; ?></title>
  <link rel="icon" type="image/png" href="<?php echo e(asset('images/icons/favicon.ico')); ?>"/>
  <!-- Custom fonts for this template -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/weball.min.css')); ?>">
  <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
  <script data-ad-client="ca-pub-5770268290169833" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
  <!-- HTML Meta Tags -->
  <title><?php echo $metaTags['title']; ?></title>
  <meta name="description" content="<?php echo $metaTags['description']; ?>">
  <meta name="keywords" content="<?php echo $metaTags['keywords']; ?>">

  <!-- Google / Search Engine Tags -->
  <meta itemprop="name" content="<?php echo $metaTags['title']; ?>">
  <meta itemprop="description" content="<?php echo $metaTags['description']; ?>">
  <meta itemprop="image" content="<?php echo $metaTags['image']; ?>">
  <meta itemprop="keywords" content="<?php echo $metaTags['keywords']; ?>">

  <!-- Facebook Meta Tags -->
  <meta property="og:url" content="https://infinitbility.com">
  <meta property="og:type" content="website">
  <meta property="og:title" content="<?php echo $metaTags['title']; ?>">
  <meta property="og:description" content="<?php echo $metaTags['description']; ?>">
  <meta property="og:image" content="<?php echo $metaTags['image']; ?>">
  <meta property="og:keywords" content="<?php echo $metaTags['keywords']; ?>">

  <!-- Twitter Meta Tags -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?php echo $metaTags['title']; ?>">
  <meta name="twitter:description" content="<?php echo $metaTags['description']; ?>">
  <meta name="twitter:image" content="<?php echo $metaTags['image']; ?>">
  <meta name="twitter:keywords" content="<?php echo $metaTags['keywords']; ?>">


  <!-- Custom styles for this template -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/clean-blog.min.css')); ?>">

</head>
<body>
    <!-- Header -->
    <?php echo $__env->make('website.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- background -->
    <?php echo $__env->make('website.layout.background', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content', View::make($viewName, $veriables)); ?>
    
    <!-- footer -->
    <?php echo $__env->make('website.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<!--===============================================================================================-->
    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
<!--===============================================================================================-->
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<!--===============================================================================================-->
 <!-- Custom scripts for this template -->
 <script src="<?php echo e(asset('js/clean-blog.min.js')); ?>"></script>
 </html><?php /**PATH C:\xampp\htdocs\infinitbility\resources\views/website/layout/app.blade.php ENDPATH**/ ?>