<!-- Main Content -->
<div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
      <div class="post-preview">
        <?php echo $post->content ?>
        <p class="post-meta">Posted by
          <a href="#"><?php echo e($post->first_name.' '.$post->last_name); ?></a>
          on <?php echo e(date('M d, Y', strtotime($post->created_at))); ?></p>
      </div>
      </div>
      <div class="col-lg-4 col-md-2 mx-auto">
      <div class="post-preview card card-body">
        <a href="#">
          <img src="<?php echo e($post->pic); ?>" width="100%" />
          <h2 class="post-title">
          <?php echo e($post->first_name.' '.$post->last_name); ?>

          </h2>
        </a>
        <p class="post-meta"><?php echo e($post->bio); ?></p>
      </div>
      <hr>
      <?php $__currentLoopData = $sponsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="post-preview card card-body">
        <a href="<?php echo e($sponser->url); ?>">
          <img src="<?php echo e($sponser->image); ?>" width="100%" />
          <h2 class="post-title">
          <?php echo e($sponser->heading); ?>

          </h2>
          <h3 class="post-subtitle">
          <?php echo e($sponser->sub_heading); ?>

          </h3>
        </a>
        <p class="post-meta"><?php echo e($sponser->description); ?></p>
      </div>
      <hr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
    <hr>
    <div>
      <h3>Releted Post</h3>
    </div>
    <div class="row">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-lg-4 col-md-12 mx-auto">
        <div class="post-preview card card-body">
          <a href="<?php echo e(url('post/'.$post->url)); ?>">
            <img src="<?php echo e($post->image); ?>" width="100%" />
            <h2 class="post-title">
              <?php echo e($post->title); ?>

            </h2>
            <h3 class="post-subtitle">
              <?php echo e($post->description); ?>

            </h3>
          </a>
          <p class="post-meta">Posted by
            <a href="#"><?php echo e($post->first_name.' '.$post->last_name); ?></a>
            on <?php echo e(date('M d, Y', strtotime($post->created_at))); ?></p>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\infinitbility\resources\views/website/pages/post.blade.php ENDPATH**/ ?>