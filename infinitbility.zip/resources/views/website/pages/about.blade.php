<div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        <p>I've been hanging around on the internet since the late nineties, so I remember a time when websites were fun, decentralized, personal havens of creativity. I want this site to be a beautiful corner of the web, and I'd like to encourage others to make their own as well.</p>
        <p>I taught myself how to make websites first as a hobby, and later as a professional programmer. I've been documenting everything I learn since I began, and the site grown to the point that it helps thousand of people every year learn new things.</p>
        <p>- Tania Rascia </p>
      </div>
    </div>
  </div>
  



